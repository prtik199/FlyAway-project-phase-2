}
//  !!!! Delete this bracket to reduce error (given bracket to alert)

//******Technologies used *************
//	Jsp
//	Servlet
//	Jdbc
//	Mysql
//
// ************* Server :************
//		Apache Tomcat 9 
	
 //************ This is the database queries ********
	
//	CREATE TABLE flight (
//			  flight_id int  NOT NULL,
//			  name varchar(128)  DEFAULT NULL,
//			  source varchar(128)  DEFAULT NULL,
//			  destination varchar(128)  DEFAULT NULL,
//			  days varchar(128)  DEFAULT NULL,
//			  ticket_price int  DEFAULT NULL,
//			  PRIMARY KEY (flight_id)
//			);
	
	
// 			Desc flight;
// 			select*from flight;

//
//			INSERT INTO flight VALUES 
//			(1,'AIR India','India','USA','MONDAY, TUESDAY, THURSDAY, SATURDAY',43000,),
//			(2,'USA Travel','USA','India','MONDAY, TUESDAY, THURSDAY, SATURDAY, FRIDAY ',32780),
//			(3,'IndiaEuropa','India','UK','MONDAY, TUESDAY, THURSDAY, SATURDAY, FRIDAY, WEDNESDAY ',54600),
//			(4,'UKAir','UK','India','MONDAY, TUESDAY, THURSDAY, SATURDAY, FRIDAY, WEDNESDAY ',43278'),
//			(5,'US-UK Space','UK','USA','MONDAY, TUESDAY, THURSDAY, SATURDAY, FRIDAY, WEDNESDAY ',34325'),
//			(6,'AmericanAirX','USA','UK','MONDAY, TUESDAY, THURSDAY, SATURDAY, FRIDAY, WEDNESDAY ',67000);
	
	
	
	
	
	
	
	
	
	

