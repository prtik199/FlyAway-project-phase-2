package model;

public class Booking {
	
    // flight details
    public static String flight_booking_id;
    public static String ticket_price;
    public static String flight_name;
    
  
    
    // Booking  details
    public static String passenger_name; 
    public static String passenger_email; 
    public static String passenger_phone; 

    // payment details
    public static String name_on_card;
    public static String card_details;
    
    }





